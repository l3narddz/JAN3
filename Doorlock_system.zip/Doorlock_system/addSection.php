<?php
  include ('connectDB.php');

  if(isset($_POST['sectionBtn'])){
    $nameTxt = $_POST['sectionName'];
    $numOfStudentTxt = $_POST['numOfStudents'];
    $appointtedSections = array('');

    // echo $nameTxt;

    $addSectionQuery = "INSERT INTO `section_tbl`(`sectionName`, `numberOfstudents`) VALUES
     ('$nameTxt','$numOfStudentTxt')";
    $result = mysqli_query($conn, $addSectionQuery);
    if($result)
    {
      $id = mysqli_insert_id($conn);
      foreach($_POST['section'] as $sectionTxt) {
        $addAppointmentSection = "INSERT INTO `appointedsection`(`appointmentId`, `sectionID`) VALUES ('$id','$sectionTxt')";
        mysqli_query($conn, $addAppointmentSection);
      }
    }else {
      echo "Error";
    }

    // echo $emailTxt;
    // echo $appointmentDateTxt;
    // echo $appointmentTimeTxt;
    // echo $appointmentNotesTxt;

    header("Location: index.php");
    exit();
  }
?>
