<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>DoorLock System</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <script src="https://kit.fontawesome.com/1658d4fd0c.js" crossorigin="anonymous"></script>
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/1658d4fd0c.js" crossorigin="anonymous"></script>
    <style>
    .fixTableHead {
      overflow-y: auto;
      height: 110px;
    }
    .fixTableHead thead th {
      position: sticky;
      top: 0;
    }
    table {
      border-collapse: collapse;
      width: 100%;
    }
    th,
    td {
      padding: 8px 15px;
      border: 2px solid #000;
    }
  </style>
  <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>
  <link rel="stylesheet" type="text/css" href="css/Users.css">
</head>
<body id="page-top">
  <?php include'header.php'; ?>
  <div class="container-fluid" class ="fixTableHead">
    <h1 class="slideInDown animated">List of Appointments</h1>
      <!--User table-->
      <div class="table-responsive slideInRight animated" style="max-height: 900px">
        <table class="table">
          <thead class="table-primary">
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Date</th>
              <th>Time-Start</th>
              <th>Time-End</th>
              <th>Action</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody class="table-secondary">
            <br>
         <?php
              //Connect to database
              require'connectDB.php';

                $sql = "SELECT * FROM appointment_tbl WHERE isActive=1 ORDER BY appointmentID DESC";
                $result = mysqli_query($conn, $sql);
                while($row = mysqli_fetch_assoc($result))
                {
              ?>
                          <TR>
                          <TD><?php echo $row['name'];?></TD>
                          <TD><?php echo $row['email'];?></TD>
                          <TD><?php echo $row['date'];?></TD>
                          <TD><?php echo date("g:ia", strtotime($row['timeStart']));?></TD>
                          <TD><?php echo date("g:ia", strtotime($row['timeEnd']));?></TD>
                          <td><select id="action" name="action">
                          <option selected></option>
                          <option value="edit">Edit</option>
                          <option value="cancel">Cancel</option>
                          </select></td>
                          <td><span class="pending">Pending</span></td>

                          </TR>
            <?php
                    }
            ?>
          </tbody>
        </table>
      </div>
  </div>
  <div class="container-fluid">
    <button id = "appoitnmentBtn" type="submit" class="btn btn-primary" data-toggle="modal" data-target="#appointmentModal">New Appointment</button>
  </div>

  <!-- Appointment MOdal!-->
  <div class="modal fade" id="appointmentModal" tabindex="-1" role="dialog" aria-labelledby="appointmentModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
  		<form action="addAppointment.php" method="POST" name="addAppointmentFrm" id="addAppointmentFrm">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="appointmentModalLabel">Make an Appointment</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
  					<div class="form-group">
  						<label for="name">Name:</label>
  						<input type="text" class="form-control" id="names" name="name" placeholder="Enter name">
  					</div>
  					<div class="form-group">
  						<label for="section">Section:</label>
  						<!-- <input type="text" class="form-control" id="section" name="section" placeholder="Enter section"> -->
  						<select id="section" name="section[]" required multiple>
  						<?php
  							   include 'connectDB.php';

  								 $querySection = "SELECT * FROM section_tbl";
  								 $result = mysqli_query($conn, $querySection);
  								 while($row = mysqli_fetch_assoc($result))
  								 {
  							?>
  							<option value="<?php echo $row['sectionID']?>"><?php echo $row['sectionName']?></option>
  							<?php
  						     }
  							?>
  						</select>
  					</div>
  					<div class="form-group">
  						<label for="email">Email:</label>
  						<input type="email" class="form-control" id="emails" name="email" placeholder="Enter email">
  					</div>
            <div class="form-group">
              <label for="appointmentDate">Date</label>
              <input type="date" class="form-control" id="appointmentDate" name="appointmentDate" placeholder="Enter date">
            </div>

            <div class="form-group">
              <label for="appointmentTimeStart">Time-Start</label>
              <input type="time" min="09:30" class="form-control" id="appointmentTimeStart" name="appointmentTimeStart" placeholder="Enter time">
            </div>
  					<div class="form-group">
              <label for="appointmentTimeEnd">Time-End</label>
              <input type="time" class="form-control" id="appointmentTimeEnd" name="appointmentTimeEnd" placeholder="Enter time">
            </div>

            <div class="form-group">
              <label for="appointmentNotes">Reason for Appointment</label>
              <textarea class="form-control" id="appointmentNotes" name="appointmentNotes" rows="3" placeholder="Enter any additional notes or details"></textarea>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" id="appointmentBtn" name="appointmentBtn" class="btn btn-primary">Save Appointment</button>
        </div>
      </div>
  	</form>
    </div>
  </div>
  <!-- Modal -->
  <script>
  $(document).ready(function () {
    $("#section").CreateMultiCheckBox({ width: '230px',
               defaultText : 'Select Below', height:'250px' });
  });
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0');
  var yyyy = today.getFullYear();
  today = yyyy + '-' + mm + '-' + dd;
  $('#appointmentDate').attr('min',today);
  </script>


</body>
</html>
